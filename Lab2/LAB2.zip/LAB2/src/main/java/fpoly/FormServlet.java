package fpoly;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/form/update")
public class FormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Tạo dữ liệu mẫu
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", "Nguyễn Văn Tèo");
        map.put("gender", true);
        map.put("country", "VN");

        // Gửi dữ liệu sang JSP
        req.setAttribute("user", map);
        req.setAttribute("editable", true);

        // Chuyển tiếp đến form.jsp
        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Nhận dữ liệu người dùng nhập trong form
        String fullname = req.getParameter("fullname");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");

        // In ra console (test)
        System.out.println("Fullname: " + fullname);
        System.out.println("Gender: " + gender);
        System.out.println("Country: " + country);

        // Gửi lại sang JSP để hiển thị
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", fullname);
        map.put("gender", Boolean.parseBoolean(gender));
        map.put("country", country);
        req.setAttribute("user", map);
        req.setAttribute("editable", false);

        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }
}

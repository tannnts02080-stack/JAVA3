package fpoly;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/form2/update")
public class FormServlet2 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Tạo đối tượng User
        User bean = new User();
        bean.setFullname("Nguyễn Văn Tèo");
        bean.setGender(true);
        bean.setCountry("VN");

        req.setAttribute("user", bean);
        req.setAttribute("editable", true);

        req.getRequestDispatcher("/form2.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String fullname = req.getParameter("fullname");
        boolean gender = Boolean.parseBoolean(req.getParameter("gender"));
        String country = req.getParameter("country");

        User bean = new User();
        bean.setFullname(fullname);
        bean.setGender(gender);
        bean.setCountry(country);

        req.setAttribute("user", bean);
        req.setAttribute("editable", false);

        req.getRequestDispatcher("/form2.jsp").forward(req, resp);
    }
}

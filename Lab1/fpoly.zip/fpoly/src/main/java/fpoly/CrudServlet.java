package fpoly;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//Ánh xạ nhiều URL vào cùng một Servlet
@WebServlet({
 "/crud/create",    // URL 1
 "/crud/update",    // URL 2
 "/crud/delete",    // URL 3
 "/crud/edit/2024"  // URL 4
})
public class CrudServlet extends HttpServlet {
 private static final long serialVersionUID = 1L;

 // Ghi đè phương thức doGet() để xử lý các yêu cầu GET
 @Override
 protected void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

     // Thiết lập kiểu nội dung trả về là HTML, có hỗ trợ tiếng Việt
     resp.setContentType("text/html;charset=UTF-8");

     // Lấy đường dẫn mà người dùng truy cập 
     String path = req.getServletPath();

     // Ghi nội dung phản hồi ra trình duyệt
     var out = resp.getWriter();

     // Xác định người dùng đang truy cập URL nào
     if (path.equals("/crud/create")) {
         out.println("<h2>Bạn vừa truy cập: /crud/create</h2>");
         out.println("<p>Chức năng: Tạo mới dữ liệu</p>");

     } else if (path.equals("/crud/update")) {
         out.println("<h2>Bạn vừa truy cập: /crud/update</h2>");
         out.println("<p>Chức năng: Cập nhật dữ liệu</p>");

     } else if (path.equals("/crud/delete")) {
         out.println("<h2>Bạn vừa truy cập: /crud/delete</h2>");
         out.println("<p>Chức năng: Xóa dữ liệu</p>");

     } else if (path.equals("/crud/edit/2024")) {
         out.println("<h2>Bạn vừa truy cập: /crud/edit/2024</h2>");
         out.println("<p>Chức năng: Chỉnh sửa dữ liệu có ID = 2024</p>");

     } else {
         out.println("<h2>Đường dẫn không hợp lệ!</h2>"); 
     }
 }
}
// http://localhost:8080/fpoly/crud/create
// http://localhost:8080/fpoly/crud/update
// http://localhost:8080/fpoly/crud/delete
// http://localhost:8080/fpoly/crud/edit/2024

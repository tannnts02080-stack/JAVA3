package fpoly;

import java.io.IOException;
//Dùng jakarta.* nếu Tomcat 10+, hoặc javax.* nếu Tomcat 9
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/home/index")
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // chuyển tiếp (forward) tới JSP trong /views/index.jsp
        req.getRequestDispatcher("/views/index.jsp").forward(req, resp);
    }
}

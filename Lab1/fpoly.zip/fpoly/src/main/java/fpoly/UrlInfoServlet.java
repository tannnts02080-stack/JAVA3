package fpoly;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/poly/urlinfo")
public class UrlInfoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Xử lý khi người dùng gửi yêu cầu GET
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Thiết lập kiểu nội dung trả về
        resp.setContentType("text/html;charset=UTF-8");

        // Ghi nội dung HTML ra trình duyệt
        var out = resp.getWriter();

        out.println("<h2>THÔNG TIN ĐỊA CHỈ URL</h2>");
        out.println("<p><b>URL:</b> " + req.getRequestURL() + "</p>");
        out.println("<p><b>URI:</b> " + req.getRequestURI() + "</p>");
        out.println("<p><b>QueryString:</b> " + req.getQueryString() + "</p>");
        out.println("<p><b>ServletPath:</b> " + req.getServletPath() + "</p>");
        out.println("<p><b>ContextPath:</b> " + req.getContextPath() + "</p>");
        out.println("<p><b>PathInfo:</b> " + req.getPathInfo() + "</p>");
        out.println("<p><b>Method:</b> " + req.getMethod() + "</p>");
    }
}
